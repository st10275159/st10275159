/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package LoginFour;

import javax.swing.*;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LoginFour {
    // variables
    private String username;
    private String password;
    private String name;
    private String surname;
    
    // Constructor
    public LoginFour(String username, String password, String name, String surname) {
        this.username = username;
        this.password = password;
        this.name = name;
        this.surname = surname;
    }

    // Register User
    public String registerUser() {
        boolean checkUsername = isCheckUsername();
        boolean checkPasswordComplexity = isCheckPasswordComplexity();

        if (checkUsername && checkPasswordComplexity) {
            JOptionPane.showMessageDialog(null, "Registration successful!");
        } else {
            if (!checkUsername) {
                JOptionPane.showMessageDialog(null, "Username is incorrect. Please ensure that your username contains an underscore and is no more than 5 characters in length");
            }
            if (!checkPasswordComplexity) {
                JOptionPane.showMessageDialog(null, "Password is incorrect. Please ensure that the password contains at least 8 characters, a capital letter, a digit, and a special character");
            }
        }
        return "Registration done!";
    }

    // Check Username
    private boolean isCheckUsername() {
        return username.contains("_") && username.length() <= 5;
    }

    // Check Password Complexity
    private boolean isCheckPasswordComplexity() {
        Pattern specialPattern = Pattern.compile("[^a-zA-Z0-9]");
        Pattern digitalPattern = Pattern.compile("[0-9]");
        Pattern capsPattern = Pattern.compile("[A-Z]");

        Matcher specialMatcher = specialPattern.matcher(password);
        Matcher digitMatcher = digitalPattern.matcher(password);
        Matcher capsMatcher = capsPattern.matcher(password);

        return password.length() >= 8 && specialMatcher.find() && digitMatcher.find() && capsMatcher.find();
    }

    // Login User
    public boolean loginUser(String inputUsername, String inputPassword) {
        return username.equals(inputUsername) && password.equals(inputPassword);
    }

    public static void main(String[] args) {
        // Example usage
        LoginFour login = new LoginFour("kyl_1", "Ch&&sec@ke99!", "John", "Doe");

        // Example: register a user
        login.registerUser();

        // Example: login with the registered credentials
        String inputUsername = JOptionPane.showInputDialog("Enter username:");
        String inputPassword = JOptionPane.showInputDialog("Enter password:");

        boolean loginStatus = login.loginUser(inputUsername, inputPassword);
        if (loginStatus) {
            JOptionPane.showMessageDialog(null, "Welcome " + login.name + " " + login.surname + ". It is great to see you again.");
            TasksFeatures tasks;
            tasks = new TasksFeatures();
            tasks.runApplication();
        } else {
            JOptionPane.showMessageDialog(null, "Username or password incorrect, please try again");
        }
    }
}