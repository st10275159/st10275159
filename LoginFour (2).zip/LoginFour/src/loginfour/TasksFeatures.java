/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package loginfour;
import javax.swing.*;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author lab_services_student
 */

 class TasksFeatures {
    private List<String> developers;
    private List<String> taskNames;
    private List<String> taskIDs;
    private List<Integer> taskDurations;
    private List<String> taskStatuses;
    private int totalHours;

    public TasksFeatures() {
        developers = new ArrayList<>();
        taskNames = new ArrayList<>();
        taskIDs = new ArrayList<>();
        taskDurations = new ArrayList<>();
        taskStatuses = new ArrayList<>();
        totalHours = 0;
    }

    public void runApplication() {
        JOptionPane.showMessageDialog(null, "Welcome to Easy Kanban");

        boolean closeProgram = false;
        int menuChoice;

        while (!closeProgram) {
            menuChoice = Integer.parseInt(JOptionPane.showInputDialog(null, "WELCOME TO EASYKANBAN"
                    + "\nPlease choose an option you would like to do :"
                    + "\n[1] - To Add tasks"
                    + "\n[2] - To Show report"
                    + "\n[3] - To Quit program"));

            switch (menuChoice) {
                case 1:
                    addTasks();
                    break;
                case 2:
                    showReport();
                    break;
                case 3:
                    JOptionPane.showMessageDialog(null, "Quitting program...");
                    closeProgram = true;
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Please enter a valid option");
                    break;
            }
        }
    }

    public void addTasks() {
        int numTasks = Integer.parseInt(JOptionPane.showInputDialog("Please enter the number of tasks you want to add!"));
        for (int i = 0; i < numTasks; i++) {
            JOptionPane.showMessageDialog(null, "Task " + (i + 1));

            String taskName = JOptionPane.showInputDialog("Please enter the name of the task:");
            String taskDescription = JOptionPane.showInputDialog("Please enter the description of the task:");
            if (taskDescription.length() > 50) {
                JOptionPane.showMessageDialog(null, "Please enter a task description of less than 50 characters");
                i--; // Repeat this task
                continue;
            }

            String devDetails = JOptionPane.showInputDialog("Please enter the developer details (First Last):");
            int taskDuration = Integer.parseInt(JOptionPane.showInputDialog("Please enter the duration of the task in hours:"));

            int choice = Integer.parseInt(JOptionPane.showInputDialog("Choose a number for the task status \n"
                    + "1 - To Do \n"
                    + "2 - Doing \n"
                    + "3 - Done \n"));

            String taskStat;
            switch (choice) {
                case 1:
                    taskStat = "To Do";
                    break;
                case 2:
                    taskStat = "Doing";
                    break;
                case 3:
                    taskStat = "Done";
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Please enter a valid option");
                    i--; // Repeat this task
                    continue;
            }

            Task task = new Task(taskName, i + 1, taskDescription, devDetails, taskDuration, taskStat);
            totalHours += taskDuration;

            // Populate arrays
            developers.add(devDetails);
            taskNames.add(taskName);
            taskIDs.add(task.createTaskID());
            taskDurations.add(taskDuration);
            taskStatuses.add(taskStat);

            JOptionPane.showMessageDialog(null, "Task successfully captured");
            task.printTaskDetails();
        }

        JOptionPane.showMessageDialog(null, "The total hours for the tasks is: " + totalHours);
        JOptionPane.showMessageDialog(null, "Thank you, all tasks have been entered into the system");
    }

    public void showReport() {
        // Display report of all captured tasks
        StringBuilder report = new StringBuilder("Full Task Report:\n");
        for (int i = 0; i < taskNames.size(); i++) {
            report.append("Task Name: ").append(taskNames.get(i)).append("\n")
                    .append("Developer: ").append(developers.get(i)).append("\n")
                    .append("Task ID: ").append(taskIDs.get(i)).append("\n")
                    .append("Task Duration: ").append(taskDurations.get(i)).append("\n")
                    .append("Task Status: ").append(taskStatuses.get(i)).append("\n\n");
        }
        JOptionPane.showMessageDialog(null, report.toString());
    }

    // Other required methods
    public void displayTasksByStatus(String status) {
        StringBuilder tasksByStatus = new StringBuilder("Tasks with status " + status + ":\n");
        for (int i = 0; i < taskNames.size(); i++) {
            if (taskStatuses.get(i).equals(status)) {
                tasksByStatus.append("Developer: ").append(developers.get(i)).append(", Task Name: ").append(taskNames.get(i)).append(", Task Duration: ").append(taskDurations.get(i)).append("\n");
            }
        }
        JOptionPane.showMessageDialog(null, tasksByStatus.toString());
    }

    public void displayLongestTask() {
        int maxDuration = 0;
        int index = 0;
        for (int i = 0; i < taskDurations.size(); i++) {
            if (taskDurations.get(i) > maxDuration) {
                maxDuration = taskDurations.get(i);
                index = i;
            }
        }
        JOptionPane.showMessageDialog(null, "Developer: " + developers.get(index) + ", Task Duration: " + taskDurations.get(index));
    }

    public void searchTaskByName(String taskName) {
        for (int i = 0; i < taskNames.size(); i++) {
            if (taskNames.get(i).equals(taskName)) {
                JOptionPane.showMessageDialog(null, "Task Name: " + taskNames.get(i) + ", Developer: " + developers.get(i) + ", Task Status: " + taskStatuses.get(i));
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Task not found");
    }

    public void searchTasksByDeveloper(String developer) {
        StringBuilder tasksByDeveloper = new StringBuilder("Tasks assigned to " + developer + ":\n");
        for (int i = 0; i < developers.size(); i++) {
            if (developers.get(i).equals(developer)) {
                tasksByDeveloper.append("Task Name: ").append(taskNames.get(i)).append(", Task Status: ").append(taskStatuses.get(i)).append("\n");
            }
        }
        JOptionPane.showMessageDialog(null, tasksByDeveloper.toString());
    }

    public void deleteTaskByName(String taskName) {
        for (int i = 0; i < taskNames.size(); i++) {
            if (taskNames.get(i).equals(taskName)) {
                developers.remove(i);
                taskNames.remove(i);
                taskIDs.remove(i);
                taskDurations.remove(i);
                taskStatuses.remove(i);
                JOptionPane.showMessageDialog(null, "Task '" + taskName + "' successfully deleted");
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Task not found");
    }
}
