/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package loginfour;
import javax.swing.*;
/**
 *
 * @author lab_services_student
 */


class Task {
    private final String taskName;
    private final int taskNumber;
    private final String taskDescription;
    private final String devDetails;
    private final int taskDuration;
    private final String taskStatus;

    public Task(String taskName, int taskNumber, String taskDescription, String devDetails, int taskDuration, String taskStatus) {
        this.taskName = taskName;
        this.taskNumber = taskNumber;
        this.taskDescription = taskDescription;
        this.devDetails = devDetails;
        this.taskDuration = taskDuration;
        this.taskStatus = taskStatus;
    }

    public boolean checkTaskDescription() {
        return taskDescription.length() <= 50;
    }

    public String createTaskID() {
        String[] devName = devDetails.split(" ");
        String initials = taskName.substring(0, 2).toUpperCase();
        String lastName = devName[1].substring(devName[1].length() - 3).toUpperCase();
        return initials + ":" + taskNumber + ":" + lastName;
    }

    public String printTaskDetails() {
        String details = "Task Status: " + taskStatus + "\n" +
                "Developer Details: " + devDetails + "\n" +
                "Task Number: " + taskNumber + "\n" +
                "Task Name: " + taskName + "\n" +
                "Task Description: " + taskDescription + "\n" +
                "Task ID: " + createTaskID() + "\n" +
                "Task Duration: " + taskDuration + " hours";

        JOptionPane.showMessageDialog(null, details);
        return details;
    }
}
