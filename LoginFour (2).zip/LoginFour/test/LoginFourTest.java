/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
import LoginFour.LoginFour;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author lab_services_student
 */
public class LoginFourTest {

    @Test
    void testLoginUser() {
        LoginFour login = new LoginFour("kyl_1", "Ch&&sec@ke99!", "John", "Doe");
        assertTrue(login.loginUser("kyl_1", "Ch&&sec@ke99!"), "User should be able to log in with correct credentials");
        assertFalse(login.loginUser("kyl_1", "wrongpassword"), "User should not be able to log in with incorrect credentials");
    }

    @Test
    void testCheckUsername() {
        LoginFour login = new LoginFour("kyl_1", "Ch&&sec@ke99!", "John", "Doe");
        assertTrue(login.isCheckUsername(), "Username check should pass for valid username");
        
        LoginFour invalidLogin = new LoginFour("kyle1", "Ch&&sec@ke99!", "John", "Doe");
        assertFalse(invalidLogin.isCheckUsername(), "Username check should fail for invalid username");
    }

    @Test
    void testCheckPasswordComplexity() {
        LoginFour login = new LoginFour("kyl_1", "Ch&&sec@ke99!", "John", "Doe");
        assertTrue(login.isCheckPasswordComplexity(), "Password complexity check should pass for valid password");

        LoginFour invalidLogin = new LoginFour("kyl_1", "password", "John", "Doe");
        assertFalse(invalidLogin.isCheckPasswordComplexity(), "Password complexity check should fail for invalid password");
    }
}